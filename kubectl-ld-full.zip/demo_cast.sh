asciinema rec demo.cast -c "./demo_full.sh"
